<h3><?php _e( 'Forever Free', 'siteorigin-north' ) ?></h3>
<p>
	<?php _e( "North is a completely free WordPress theme.", 'siteorigin-north' ) ?>
	<?php _e( "We'll continue developing and enhancing it for years to come.", 'siteorigin-north' ) ?>
</p>
