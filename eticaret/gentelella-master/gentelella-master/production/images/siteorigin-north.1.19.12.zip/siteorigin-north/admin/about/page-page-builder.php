<h3><?php _e( 'Enhanced by Page Builder', 'siteorigin-north' ) ?></h3>
<p>
	<?php printf( __( "North integrates, beautifully, with our %sfree Page Builder%s plugin.", 'siteorigin-north' ), '<a href="https://siteorigin.com/page-builder/">', '</a>' ) ?>
	<?php _e( 'This powerful plugin gives you full drag and drop capabilities right inside North.', 'siteorigin-north' ) ?>
</p>
