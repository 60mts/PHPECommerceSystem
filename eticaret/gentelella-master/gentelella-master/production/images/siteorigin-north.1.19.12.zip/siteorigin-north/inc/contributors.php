<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 1716,
		"score": 14.039718132326419,
		"percent": 40.9077491483845
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 409,
		"score": 11.329382181685173,
		"percent": 33.01060035011954
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 5163,
		"score": 6.4985722847205185,
		"percent": 18.93499302054294
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 65,
		"score": 2.0181065285194655,
		"percent": 5.880188964285964
	},
	"0f7f79a15dafbc4c1b64dfdc79c6937d": {
		"name": "adiraomj",
		"email": "0f7f79a15dafbc4c1b64dfdc79c6937d",
		"loc": 331,
		"score": 0.1935717222950337,
		"percent": 0.564012993938494
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 48,
		"score": 0.11980565850538626,
		"percent": 0.34907964522527446
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 12,
		"score": 0.062280674784612765,
		"percent": 0.18146818881034643
	},
	"7b5cecaa8974094d0c46c5b9a58fb614": {
		"name": "Sylvain Tissot",
		"email": "7b5cecaa8974094d0c46c5b9a58fb614",
		"loc": 1,
		"score": 0.05831257878455288,
		"percent": 0.16990628462984847
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2,
		"score": 0.0006868906136321929,
		"percent": 0.002001404063102052
	}
}', true );